# Version number and release date.
VERSION_NUMBER=1.1
RELEASE_DATE=2022-10-16      # in "date +%Y-%m-%d" format

# Version of gnulib that was used in this release.
GNULIB_GIT_COMMIT=2118e7cf12997850652002b3af3c44511c98f4bc
