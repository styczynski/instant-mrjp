# instant-mrjp
ps386038
Instant compiler (MRJP) 2023/2024

Wykorzystane biblioteki:
- parser-combinators (parser)
- megaparsec (parser)
- co-log (ładne logowanie)
- diagnose (ładne błędy megaparsec)
- jvm-parser (ast do obsługi kodu jvm)