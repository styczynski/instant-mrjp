module Main where

import Latte

main :: IO ()
main = runCLI ()
